import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge, Empty, FormGrid, PageTitle, clean, missing, friendlyError, useStaff, type FieldDef } from "./kit";
import { inr } from "@/lib/admin/csv";

type Vehicle = Database["public"]["Tables"]["vehicles"]["Row"];
const statuses = ["In Stock", "Inspection Pending", "Reconditioning", "Available for Sale", "Reserved", "Sold", "Archived"];
const fields: FieldDef[] = [
  { key: "stock_id", label: "Stock ID", required: true }, { key: "make", label: "Make", required: true },
  { key: "model", label: "Model", required: true }, { key: "variant", label: "Variant / trim" },
  { key: "mfg_year", label: "Manufacturing year", type: "number" }, { key: "reg_year", label: "Registration year", type: "number" },
  { key: "fuel_type", label: "Fuel type", type: "select", options: ["Petrol", "Diesel", "CNG", "Electric", "Hybrid", "Other"] },
  { key: "transmission", label: "Transmission", type: "select", options: ["Manual", "Automatic", "AMT", "CVT", "DCT", "Other"] },
  { key: "odometer_km", label: "Odometer (km)", type: "number" }, { key: "owners", label: "Number of owners", type: "number" },
  { key: "condition", label: "Condition" }, { key: "registration", label: "Registration number (internal)" },
  { key: "purchase_price", label: "Purchase price (₹)", type: "number" }, { key: "asking_price", label: "Asking price (₹)", type: "number" },
  { key: "status", label: "Status", type: "select", options: statuses, required: true },
  { key: "description", label: "Description", type: "textarea", wide: true },
  { key: "photos_text", label: "Photo URLs (one per line)", type: "textarea", wide: true },
];

export function Vehicles() {
  const { can } = useStaff();
  const [vehicles, setVehicles] = useState<Vehicle[] | null>(null);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("Available for Sale");
  const [edit, setEdit] = useState<Record<string, unknown> | null>(null);
  const [saving, setSaving] = useState(false);
  const editable = can("vehicles");
  const load = useCallback(() => supabase.from("vehicles").select("*").order("updated_at", { ascending: false }).then(({ data, error }) => {
    if (error) toast.error(error.message);
    setVehicles(data ?? []);
  }), []);
  useEffect(() => { void load(); }, [load]);

  const list = useMemo(() => (vehicles ?? []).filter((v) => (!status || v.status === status) &&
    (!query || [v.stock_id, v.make, v.model, v.variant, v.registration].join(" ").toLowerCase().includes(query.toLowerCase()))), [vehicles, query, status]);

  function startEdit(v?: Vehicle) {
    if (!v) { setEdit({ stock_id: "", make: "", model: "", status: "In Stock", purchase_price: 0, photos_text: "" }); return; }
    setEdit({ ...v, photos_text: (v.photos ?? []).join("\n") });
  }

  async function save() {
    if (!edit) return;
    const required = missing(fields.filter((f) => f.key !== "photos_text"), edit);
    if (required) { toast.error(`${required} is required`); return; }
    const data = clean(fields.filter((f) => f.key !== "photos_text"), edit) as Record<string, unknown>;
    data.photos = String(edit.photos_text ?? "").split("\n").map((u) => u.trim()).filter((u) => /^https?:\/\//i.test(u));
    delete data.photos_text;
    if (data.status === "Sold" && (!edit.id || vehicles?.find((v) => v.id === edit.id)?.status !== "Sold")) { toast.error('Use the Record Sale workflow to mark a vehicle as sold.'); return; }
    setSaving(true);
    const result = edit.id
      ? await supabase.from("vehicles").update(data as never).eq("id", String(edit.id))
      : await supabase.from("vehicles").insert(data as never);
    setSaving(false);
    if (result.error) { toast.error(friendlyError(result.error.message)); return; }
    toast.success("Vehicle saved"); setEdit(null); await load();
  }

  return <div>
    <PageTitle title="Vehicle inventory" sub="Manage stock records and asking prices. Sensitive fields are staff-only.">
      {editable && <Button onClick={() => startEdit()}><Plus className="size-4" /> Add vehicle</Button>}
    </PageTitle>
    <div className="mb-4 flex flex-col gap-3 sm:flex-row">
      <div className="relative flex-1"><Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" /><Input className="pl-9" placeholder="Search stock ID, make, model…" value={query} onChange={(e) => setQuery(e.target.value)} /></div>
      <select aria-label="Filter vehicle status" className="h-10 rounded-md border border-input bg-background px-3 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="">All statuses</option>{statuses.map((v) => <option key={v} value={v}>{v}</option>)}
      </select>
    </div>
    {vehicles === null ? <Empty>Loading vehicles…</Empty> : !list.length ? <Empty>No vehicles match these filters.</Empty> : <div className="overflow-x-auto rounded-md border border-border">
      <table className="w-full min-w-[760px] text-sm"><thead className="bg-muted/40 text-left text-xs uppercase tracking-wider text-muted-foreground"><tr>{["Stock ID", "Vehicle", "Year", "Fuel / Gearbox", "Odometer", "Asking price", "Status", ""].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-border">{list.map((v) => <tr key={v.id} className="hover:bg-muted/20">
          <td className="p-3 font-semibold">{v.stock_id}</td><td className="p-3">{v.make} {v.model}{v.variant ? ` · ${v.variant}` : ""}</td><td className="p-3">{v.mfg_year ?? "—"}</td><td className="p-3">{[v.fuel_type, v.transmission].filter(Boolean).join(" · ") || "—"}</td><td className="p-3">{v.odometer_km == null ? "—" : `${v.odometer_km.toLocaleString("en-IN")} km`}</td><td className="p-3">{v.asking_price == null ? "—" : inr(v.asking_price)}</td><td className="p-3"><Badge v={v.status} /></td><td className="p-3 text-right">{editable && <Button size="sm" variant="outline" onClick={() => startEdit(v)}>Edit</Button>}</td>
        </tr>)}</tbody>
      </table>
    </div>}
    {edit && <Dialog open onOpenChange={(open) => !open && setEdit(null)}><DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto"><DialogHeader><DialogTitle>{edit.id ? "Edit vehicle" : "Add vehicle"}</DialogTitle></DialogHeader>
      <p className="text-sm text-muted-foreground">Use unique stock IDs. Registration/VIN are internal fields; do not put them in public descriptions.</p>
      <FormGrid fields={fields} value={edit} onChange={setEdit} disabled={saving} />
      <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => setEdit(null)} disabled={saving}>Cancel</Button><Button onClick={() => void save()} disabled={saving}>{saving ? "Saving…" : "Save vehicle"}</Button></div>
    </DialogContent></Dialog>}
  </div>;
}
