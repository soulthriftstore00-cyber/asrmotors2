# ASR Motors — Premium Multi-Brand Workshop

A React 19 + TanStack Start website for ASR Motors, Madhapur, Hyderabad. It includes public service pages, booking/enquiry flows, WhatsApp contact links, website content management, and a staff dashboard backed by Supabase.

## Requirements

- Node.js 22 or newer
- npm 10+ (or Bun if you prefer the included `bun.lock`)
- A Supabase project with the SQL migrations in `drizzle/migrations/` applied

## Run locally

1. Copy `.env.example` to `.env` and fill in your Supabase project URL and publishable key.
2. Install dependencies: `npm install`
3. Start the dev server: `npm run dev`
4. Verify changes: `npm run lint`, `npm test`, and `npm run build`.

Do not commit `.env`, service-role keys, database passwords, or other credentials. The browser should only receive the Supabase publishable/anon key; service-role keys must remain server-side. Rotate any secret that has ever been committed or shared unintentionally.

## Deploy to Vercel

1. Push this project to a private or public GitHub repository.
2. In Vercel, choose **Add New → Project**, import the repository, and select the correct production branch.
3. In Vercel project settings, set `NITRO_PRESET=vercel` as an Environment Variable and use `npm run build` as the build command so Nitro targets Vercel rather than the default Cloudflare preset. Do not force a static export because the project uses server rendering and server functions.
4. Add the environment variables from `.env.example` in **Project Settings → Environment Variables** for Development, Preview, and Production as appropriate. Never add `SUPABASE_SERVICE_ROLE_KEY` as a `VITE_*` variable.
5. Deploy a Preview first and test `/`, `/services`, `/book`, `/contact`, and `/admin`. Then promote/merge to production.
6. Add your production domain in Vercel and update the canonical site URL in `src/lib/site.ts` (`SITE_URL`) and the structured-data URL in `src/components/site/Sections.tsx` (`autoRepairLd`) to match the real domain.
7. In Supabase Auth settings, add the production and preview URLs to the allowed redirect URLs. Confirm Row Level Security policies and staff roles before using the admin area.

## Current admin capabilities

The staff dashboard includes enquiries/service bookings, website content editing, parts/stock movements, suppliers, and customers (shown according to staff role). The database migration also defines vehicle, reservation, and sales tables; a complete vehicle CRUD/sales workflow and a public used-car catalogue still need their own UI and a deliberate public-data access policy before launch. Do not make private stock, purchase price, VIN, registration, or customer records publicly readable.

## Before production

- Confirm workshop phone, WhatsApp, address, business hours, reviews, and domain are correct.
- Apply all database migrations in order and test with a non-admin staff account.
- Test booking submission, WhatsApp links, file/media uploads, and role restrictions.
- Run `npm run lint`, `npm test`, and `npm run build` in CI.
- Check Vercel logs and browser console on the Preview deployment.
